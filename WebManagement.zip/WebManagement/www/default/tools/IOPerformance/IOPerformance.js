﻿var SystemPerformanceConnection,IOChart;$(function(){var n=new IOChart("IO");new SystemPerformanceConnection("ioPerfConnectionStatus",{ioCallback:n.onMessageCallback})});
/*!
//@ sourceURL=tools/IOPerformance/IOPerformance.js
*/
